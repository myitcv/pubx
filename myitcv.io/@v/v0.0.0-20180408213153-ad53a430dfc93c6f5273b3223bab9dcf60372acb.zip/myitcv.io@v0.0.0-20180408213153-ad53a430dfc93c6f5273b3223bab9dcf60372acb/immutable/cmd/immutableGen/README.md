immutableGen is a `go generate` generator that creates immutable struct, map and slice type declarations from template
type declarations.

See [the `immutableGen` wiki](https://myitcv.io/immutable/wiki/immutableGen) for more details.
