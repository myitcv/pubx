package main

//go:generate ls
