package main

//go:generate "/bin/ls"
