package example

type _Imm_myTestMap map[string]int
