package coretest_test

const (
	paul  = "paul"
	peter = "peter"
	age42 = 42
)
