// +build debug

package main

const (
	debug       = true
	panicErrors = true
)
