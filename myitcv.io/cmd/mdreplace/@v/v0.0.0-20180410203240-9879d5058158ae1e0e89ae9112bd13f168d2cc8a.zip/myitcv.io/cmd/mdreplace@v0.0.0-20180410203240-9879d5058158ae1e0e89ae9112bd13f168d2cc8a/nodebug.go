// +build !debug

package main

const (
	debug       = false
	panicErrors = false
)
